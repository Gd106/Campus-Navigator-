import { SiteHeader } from "@/components/site-header"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

export default function AboutPage() {
  return (
    <div className="flex min-h-screen flex-col">
      <SiteHeader />
      <main className="flex-1">
        <div className="container py-6">
          <h1 className="text-3xl font-bold mb-6">About Campus Navigator</h1>

          <Tabs defaultValue="about">
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="about">About</TabsTrigger>
              <TabsTrigger value="help">Help & FAQ</TabsTrigger>
              <TabsTrigger value="contact">Contact</TabsTrigger>
            </TabsList>

            <TabsContent value="about" className="space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle>Campus Navigator</CardTitle>
                  <CardDescription>Your guide to navigating the university campus</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <p>
                    Campus Navigator is a comprehensive web application designed to help students, faculty, staff, and
                    visitors navigate the university campus with ease. Our interactive map and detailed building
                    information make it simple to find your way around campus.
                  </p>
                  <p>
                    Whether you're a new student trying to find your classes, a visitor attending an event, or a faculty
                    member looking for a specific facility, Campus Navigator provides the tools you need to get where
                    you're going.
                  </p>
                  <h3 className="text-lg font-semibold mt-4">Features</h3>
                  <ul className="list-disc pl-5 space-y-1">
                    <li>Interactive campus map with building locations</li>
                    <li>Detailed information about campus buildings and facilities</li>
                    <li>Turn-by-turn directions between buildings</li>
                    <li>Building hours and access information</li>
                    <li>Search functionality to quickly find what you need</li>
                  </ul>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="help" className="space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle>Frequently Asked Questions</CardTitle>
                  <CardDescription>Common questions about using Campus Navigator</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-4">
                    <div>
                      <h3 className="text-lg font-semibold">How do I find a specific building?</h3>
                      <p className="text-muted-foreground">
                        You can use the search bar at the top of the page to search for buildings by name, or browse the
                        complete list of buildings on the Buildings page.
                      </p>
                    </div>
                    <div>
                      <h3 className="text-lg font-semibold">How do I get directions between buildings?</h3>
                      <p className="text-muted-foreground">
                        Visit the Directions page, select your starting point and destination from the dropdown menus,
                        and click "Get Directions" to see a route on the map and step-by-step instructions.
                      </p>
                    </div>
                    <div>
                      <h3 className="text-lg font-semibold">Is my current location shown on the map?</h3>
                      <p className="text-muted-foreground">
                        Yes, if you grant location permissions to the website, your current location will be displayed
                        on the map with a blue dot. Click the location button in the bottom right of the map to center
                        on your location.
                      </p>
                    </div>
                    <div>
                      <h3 className="text-lg font-semibold">How accurate are the building hours?</h3>
                      <p className="text-muted-foreground">
                        Building hours are updated regularly, but may change during holidays, breaks, or special events.
                        Always check the university website or contact the specific department for the most up-to-date
                        information.
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="contact" className="space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle>Contact Us</CardTitle>
                  <CardDescription>Get in touch with the Campus Navigator team</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <p>
                    If you have questions, feedback, or need assistance with Campus Navigator, please contact us using
                    the information below:
                  </p>
                  <div className="space-y-2">
                    <p>
                      <strong>Email:</strong> campusnavigator@university.edu
                    </p>
                    <p>
                      <strong>Phone:</strong> (123) 456-7890
                    </p>
                    <p>
                      <strong>Office:</strong> Student Services Building, Room 101
                    </p>
                  </div>
                  <p className="mt-4">
                    For technical support or to report issues with the application, please include details about the
                    problem you're experiencing, including the device and browser you're using.
                  </p>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </main>
    </div>
  )
}
