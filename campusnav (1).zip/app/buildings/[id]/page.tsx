import { SiteHeader } from "@/components/site-header"
import { buildings } from "@/lib/data"
import { BuildingDetails } from "@/components/building-details"
import { notFound } from "next/navigation"

interface BuildingPageProps {
  params: {
    id: string
  }
}

export default function BuildingPage({ params }: BuildingPageProps) {
  const building = buildings.find((b) => b.id === params.id)

  if (!building) {
    notFound()
  }

  return (
    <div className="flex min-h-screen flex-col">
      <SiteHeader />
      <main className="flex-1">
        <div className="container py-6">
          <BuildingDetails building={building} />
        </div>
      </main>
    </div>
  )
}
