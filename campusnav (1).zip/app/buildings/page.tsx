import { BuildingCard } from "@/components/building-card"
import { SearchBar } from "@/components/search-bar"
import { SiteHeader } from "@/components/site-header"
import { buildings } from "@/lib/data"

export default function BuildingsPage() {
  return (
    <div className="flex min-h-screen flex-col">
      <SiteHeader />
      <main className="flex-1">
        <div className="container py-6">
          <h1 className="text-3xl font-bold mb-6">Campus Buildings</h1>
          <div className="mb-6">
            <SearchBar />
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {buildings.map((building) => (
              <BuildingCard key={building.id} building={building} />
            ))}
          </div>
        </div>
      </main>
    </div>
  )
}
