import { SiteHeader } from "@/components/site-header"
import { DirectionsForm } from "@/components/directions-form"

export default function DirectionsPage() {
  return (
    <div className="flex min-h-screen flex-col">
      <SiteHeader />
      <main className="flex-1">
        <div className="container py-6">
          <h1 className="text-3xl font-bold mb-6">Get Directions</h1>
          <DirectionsForm />
        </div>
      </main>
    </div>
  )
}
