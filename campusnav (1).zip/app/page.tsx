import { CampusMap } from "@/components/campus-map"
import { SearchBar } from "@/components/search-bar"
import { SiteHeader } from "@/components/site-header"

export default function Home() {
  return (
    <div className="flex min-h-screen flex-col">
      <SiteHeader />
      <main className="flex-1">
        <div className="container relative">
          <div className="my-4">
            <SearchBar />
          </div>
          <CampusMap />
        </div>
      </main>
    </div>
  )
}
