export interface Building {
  id: string
  name: string
  description: string
  category: string
  location: string
  coordinates: [number, number]
  image?: string
  facilities?: string[]
  departments?: string[]
  hours?: {
    weekdays: string
    saturday: string
    sunday: string
  }
  access?: string
}

export interface Route {
  path: [number, number][]
  instructions: string[]
}
