import type { Building, Route } from "./types"

// This would normally be in an environment variable
// For the demo, we'll use a placeholder that the user will replace
const MAPBOX_TOKEN = "pk.eyJ1IjoiamF0aW5tMDAwNyIsImEiOiJjbTl6enpvcXUxc2w1MmlzZTUzMXA5YWEzIn0.KSnQ45DAeguB7_-MHFcl5Q"

export async function calculateRoute(start: Building, end: Building): Promise<Route> {
  try {
    // Use Mapbox Directions API for accurate routing
    const response = await fetch(
      `https://api.mapbox.com/directions/v5/mapbox/walking/${start.coordinates[0]},${start.coordinates[1]};${end.coordinates[0]},${end.coordinates[1]}?steps=true&geometries=geojson&access_token=${MAPBOX_TOKEN}`,
      {
        method: "GET",
        headers: {
          "Content-Type": "application/json",
        },
      },
    )

    if (!response.ok) {
      console.warn(`Mapbox API returned status ${response.status}. Falling back to simple routing.`)
      return fallbackRouting(start, end)
    }

    const data = await response.json()

    if (!data.routes || data.routes.length === 0) {
      console.warn("No routes found in Mapbox response. Falling back to simple routing.")
      return fallbackRouting(start, end)
    }

    const route = data.routes[0]
    const path = route.geometry.coordinates.map((coord: number[]) => [coord[1], coord[0]] as [number, number])

    // Extract step-by-step instructions
    const instructions = route.legs[0].steps.map((step: any) => step.maneuver.instruction)

    // Add summary information
    const distance = Math.round(route.distance)
    const duration = Math.round(route.duration / 60) // Convert seconds to minutes

    instructions.push(`Total distance: approximately ${distance} meters (about ${duration} minutes walking).`)

    return { path, instructions }
  } catch (error) {
    console.error("Error calculating route:", error)
    // Fallback to simple direct routing if Mapbox API fails
    return fallbackRouting(start, end)
  }
}

// Fallback routing function in case the API call fails
function fallbackRouting(start: Building, end: Building): Route {
  // Create a path with a few points between start and end
  const startCoord = start.coordinates
  const endCoord = end.coordinates

  // Calculate midpoints to simulate a path
  const midPoint1: [number, number] = [
    startCoord[0] + (endCoord[0] - startCoord[0]) * 0.25,
    startCoord[1] + (endCoord[1] - startCoord[1]) * 0.25,
  ]

  const midPoint2: [number, number] = [
    startCoord[0] + (endCoord[0] - startCoord[0]) * 0.5,
    startCoord[1] + (endCoord[1] - startCoord[1]) * 0.5,
  ]

  const midPoint3: [number, number] = [
    startCoord[0] + (endCoord[0] - startCoord[0]) * 0.75,
    startCoord[1] + (endCoord[1] - startCoord[1]) * 0.75,
  ]

  const path: [number, number][] = [startCoord, midPoint1, midPoint2, midPoint3, endCoord]

  // Calculate approximate distance in meters
  const distance = calculateDistance(startCoord, endCoord)
  const walkingTime = Math.round(distance / 80) // Assuming 80 meters per minute walking speed

  // Generate instructions
  const instructions: string[] = [
    `Start at ${start.name}.`,
    `Head ${getDirection(startCoord, midPoint1)} towards the ${getNearestLandmark(midPoint1)}.`,
    `Continue ${getDirection(midPoint1, midPoint2)} past the ${getNearestLandmark(midPoint2)}.`,
    `Turn ${getDirection(midPoint2, midPoint3)} and walk towards ${getNearestLandmark(midPoint3)}.`,
    `Arrive at your destination: ${end.name}.`,
    `Total distance: approximately ${Math.round(distance)} meters (about ${walkingTime} minutes walking).`,
  ]

  return { path, instructions }
}

// Helper function to calculate distance between two coordinates
function calculateDistance(coord1: [number, number], coord2: [number, number]): number {
  const R = 6371000 // Earth's radius in meters
  const dLat = ((coord2[1] - coord1[1]) * Math.PI) / 180
  const dLon = ((coord2[0] - coord1[0]) * Math.PI) / 180
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos((coord1[1] * Math.PI) / 180) *
      Math.cos((coord2[1] * Math.PI) / 180) *
      Math.sin(dLon / 2) *
      Math.sin(dLon / 2)
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a))
  return R * c
}

// Helper function to get a cardinal direction between two points
function getDirection(from: [number, number], to: [number, number]): string {
  const dx = to[0] - from[0]
  const dy = to[1] - from[1]
  const angle = (Math.atan2(dy, dx) * 180) / Math.PI

  if (angle >= -22.5 && angle < 22.5) return "east"
  if (angle >= 22.5 && angle < 67.5) return "northeast"
  if (angle >= 67.5 && angle < 112.5) return "north"
  if (angle >= 112.5 && angle < 157.5) return "northwest"
  if (angle >= 157.5 || angle < -157.5) return "west"
  if (angle >= -157.5 && angle < -112.5) return "southwest"
  if (angle >= -112.5 && angle < -67.5) return "south"
  return "southeast"
}

// Helper function to get a fictional landmark near a coordinate
function getNearestLandmark(coord: [number, number]): string {
  // In a real app, this would query a database of campus landmarks
  // For this demo, we'll return random landmarks
  const landmarks = [
    "main gate",
    "fountain",
    "campus store",
    "bike racks",
    "information kiosk",
    "bus stop",
    "campus cafe",
    "statue",
    "garden",
  ]

  // Use the coordinates to deterministically select a landmark
  const index = Math.floor((Math.abs(coord[0] * 1000) + Math.abs(coord[1] * 1000)) % landmarks.length)

  return landmarks[index]
}
