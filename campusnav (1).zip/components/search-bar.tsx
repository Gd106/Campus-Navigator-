"use client"

import { useState } from "react"
import { Search } from "lucide-react"
import { Button } from "@/components/ui/button"
import { buildings } from "@/lib/data"
import {
  CommandDialog,
  CommandEmpty,
  CommandGroup,
  CommandInput,
  CommandItem,
  CommandList,
} from "@/components/ui/command"
import { useRouter } from "next/navigation"

export function SearchBar() {
  const [open, setOpen] = useState(false)
  const router = useRouter()

  const handleSelect = (buildingId: string) => {
    setOpen(false)
    router.push(`/buildings/${buildingId}`)
  }

  return (
    <>
      <div className="relative">
        <Button variant="outline" className="w-full justify-start text-muted-foreground" onClick={() => setOpen(true)}>
          <Search className="mr-2 h-4 w-4" />
          Search for a building, classroom, or facility...
        </Button>
      </div>
      <CommandDialog open={open} onOpenChange={setOpen}>
        <CommandInput placeholder="Search for a building, classroom, or facility..." />
        <CommandList>
          <CommandEmpty>No results found.</CommandEmpty>
          <CommandGroup heading="Buildings">
            {buildings.map((building) => (
              <CommandItem key={building.id} onSelect={() => handleSelect(building.id)}>
                {building.name}
              </CommandItem>
            ))}
          </CommandGroup>
        </CommandList>
      </CommandDialog>
    </>
  )
}
