"use client"

import Image from "next/image"
import type { Building } from "@/lib/types"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { MapPin, Navigation2 } from "lucide-react"
import { useRouter } from "next/navigation"
import { useState, useEffect, useRef } from "react"
import mapboxgl from "mapbox-gl"
import "mapbox-gl/dist/mapbox-gl.css"

// This would normally be in an environment variable
// For the demo, we'll use a placeholder that the user will replace
const MAPBOX_TOKEN = "pk.eyJ1IjoiamF0aW5tMDAwNyIsImEiOiJjbTl6enpvcXUxc2w1MmlzZTUzMXA5YWEzIn0.KSnQ45DAeguB7_-MHFcl5Q"

interface BuildingDetailsProps {
  building: Building
}

// Create a fallback marker element if the image is not available
function createMarkerElement() {
  const el = document.createElement("div")
  el.className = "marker"

  try {
    el.style.backgroundImage = `url(/marker-icon.png)`
    el.style.width = "25px"
    el.style.height = "41px"
    el.style.backgroundSize = "cover"
  } catch (error) {
    // Fallback to a simple colored div if image fails
    el.style.width = "20px"
    el.style.height = "20px"
    el.style.borderRadius = "50%"
    el.style.backgroundColor = "#3887be"
    el.style.border = "2px solid white"
  }

  el.style.cursor = "pointer"
  return el
}

export function BuildingDetails({ building }: BuildingDetailsProps) {
  const router = useRouter()
  const mapContainer = useRef<HTMLDivElement>(null)
  const map = useRef<mapboxgl.Map | null>(null)
  const [isMounted, setIsMounted] = useState(false)

  useEffect(() => {
    setIsMounted(true)

    if (!mapContainer.current || map.current) return

    // Initialize map
    mapboxgl.accessToken = MAPBOX_TOKEN

    try {
      map.current = new mapboxgl.Map({
        container: mapContainer.current,
        style: "mapbox://styles/mapbox/streets-v12",
        center: building.coordinates,
        zoom: 17,
      })

      // Add navigation controls
      map.current.addControl(new mapboxgl.NavigationControl(), "top-right")

      // Add marker for the building
      const popup = new mapboxgl.Popup({ offset: 25 }).setHTML(`
        <div style="text-align: center;">
          <h3 style="font-weight: bold;">${building.name}</h3>
          <p style="font-size: 0.875rem; color: #666;">${building.location}</p>
        </div>
      `)

      // Replace the existing marker creation code with:
      new mapboxgl.Marker(createMarkerElement()).setLngLat(building.coordinates).setPopup(popup).addTo(map.current)
    } catch (error) {
      console.error("Error initializing map:", error)
    }

    return () => {
      if (map.current) {
        map.current.remove()
        map.current = null
      }
    }
  }, [building])

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row gap-4 items-start">
        <Button variant="ghost" onClick={() => router.back()} className="mb-2">
          ← Back
        </Button>
        <div className="flex-1">
          <h1 className="text-3xl font-bold">{building.name}</h1>
          <div className="flex items-center mt-2 text-muted-foreground">
            <MapPin className="h-4 w-4 mr-1" />
            <span>{building.location}</span>
          </div>
        </div>
        <div className="flex gap-2">
          <Button onClick={() => router.push(`/directions?from=&to=${building.id}`)}>
            <Navigation2 className="mr-2 h-4 w-4" />
            Get Directions
          </Button>
        </div>
      </div>

      <div className="relative h-64 w-full rounded-lg overflow-hidden">
        <Image
          src={building.image || `/placeholder.svg?height=400&width=800`}
          alt={building.name}
          fill
          className="object-cover"
        />
      </div>

      <Tabs defaultValue="info">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="info">Information</TabsTrigger>
          <TabsTrigger value="hours">Hours & Access</TabsTrigger>
          <TabsTrigger value="map">Map</TabsTrigger>
        </TabsList>
        <TabsContent value="info" className="space-y-4">
          <Card>
            <CardContent className="pt-6">
              <h3 className="text-lg font-semibold mb-2">About</h3>
              <p>{building.description}</p>

              <h3 className="text-lg font-semibold mt-4 mb-2">Facilities</h3>
              <ul className="list-disc pl-5 space-y-1">
                {building.facilities?.map((facility, index) => (
                  <li key={index}>{facility}</li>
                ))}
              </ul>

              <h3 className="text-lg font-semibold mt-4 mb-2">Departments</h3>
              <ul className="list-disc pl-5 space-y-1">
                {building.departments?.map((department, index) => (
                  <li key={index}>{department}</li>
                ))}
              </ul>
            </CardContent>
          </Card>
        </TabsContent>
        <TabsContent value="hours">
          <Card>
            <CardContent className="pt-6 space-y-4">
              <h3 className="text-lg font-semibold mb-2">Opening Hours</h3>
              <div className="space-y-2">
                <div className="flex justify-between">
                  <span>Monday - Friday</span>
                  <span>{building.hours?.weekdays || "8:00 AM - 6:00 PM"}</span>
                </div>
                <div className="flex justify-between">
                  <span>Saturday</span>
                  <span>{building.hours?.saturday || "9:00 AM - 1:00 PM"}</span>
                </div>
                <div className="flex justify-between">
                  <span>Sunday</span>
                  <span>{building.hours?.sunday || "Closed"}</span>
                </div>
              </div>

              <h3 className="text-lg font-semibold mt-4 mb-2">Access Information</h3>
              <p>{building.access || "Building access requires a valid university ID after 6:00 PM."}</p>
            </CardContent>
          </Card>
        </TabsContent>
        <TabsContent value="map">
          <Card>
            <CardContent className="pt-6">
              {isMounted && <div className="h-[400px] w-full" ref={mapContainer}></div>}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
