import Image from "next/image"
import Link from "next/link"
import type { Building } from "@/lib/types"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { MapPin } from "lucide-react"

interface BuildingCardProps {
  building: Building
}

export function BuildingCard({ building }: BuildingCardProps) {
  return (
    <Card className="overflow-hidden">
      <div className="relative h-48 w-full">
        <Image
          src={building.image || `/placeholder.svg?height=400&width=600`}
          alt={building.name}
          fill
          className="object-cover"
        />
      </div>
      <CardHeader>
        <CardTitle>{building.name}</CardTitle>
        <CardDescription>{building.category}</CardDescription>
      </CardHeader>
      <CardContent>
        <p className="text-sm text-muted-foreground line-clamp-3">{building.description}</p>
        <div className="flex items-center mt-2 text-sm text-muted-foreground">
          <MapPin className="h-4 w-4 mr-1" />
          <span>{building.location}</span>
        </div>
      </CardContent>
      <CardFooter>
        <Button asChild className="w-full">
          <Link href={`/buildings/${building.id}`}>View Details</Link>
        </Button>
      </CardFooter>
    </Card>
  )
}
