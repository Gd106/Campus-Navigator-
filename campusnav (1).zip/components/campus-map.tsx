"use client"

import { useEffect, useState, useRef } from "react"
import { buildings } from "@/lib/data"
import { Button } from "@/components/ui/button"
import { useRouter } from "next/navigation"
import { Card, CardContent } from "@/components/ui/card"
import { Navigation } from "lucide-react"
import mapboxgl from "mapbox-gl"
import "mapbox-gl/dist/mapbox-gl.css"

// This would normally be in an environment variable
// For the demo, we'll use a placeholder that the user will replace
const MAPBOX_TOKEN = "pk.eyJ1IjoiamF0aW5tMDAwNyIsImEiOiJjbTl6enpvcXUxc2w1MmlzZTUzMXA5YWEzIn0.KSnQ45DAeguB7_-MHFcl5Q"

// Create a fallback marker element if the image is not available
function createMarkerElement() {
  const el = document.createElement("div")
  el.className = "marker"

  try {
    el.style.backgroundImage = `url(/marker-icon.png)`
    el.style.width = "25px"
    el.style.height = "41px"
    el.style.backgroundSize = "cover"
  } catch (error) {
    // Fallback to a simple colored div if image fails
    el.style.width = "20px"
    el.style.height = "20px"
    el.style.borderRadius = "50%"
    el.style.backgroundColor = "#3887be"
    el.style.border = "2px solid white"
  }

  el.style.cursor = "pointer"
  return el
}

export function CampusMap() {
  const router = useRouter()
  const mapContainer = useRef<HTMLDivElement>(null)
  const map = useRef<mapboxgl.Map | null>(null)
  const [isMounted, setIsMounted] = useState(false)
  const [userLocation, setUserLocation] = useState<[number, number] | null>(null)

  // IIT Delhi center coordinates (default view)
  const campusCenter: [number, number] = [77.1929, 28.5459]

  useEffect(() => {
    setIsMounted(true)

    if (!mapContainer.current || map.current) return

    // Initialize map
    mapboxgl.accessToken = MAPBOX_TOKEN

    const initializeMap = () => {
      try {
        map.current = new mapboxgl.Map({
          container: mapContainer.current!,
          style: "mapbox://styles/mapbox/streets-v12",
          center: campusCenter,
          zoom: 15,
        })

        // Add navigation controls
        map.current.addControl(new mapboxgl.NavigationControl(), "top-right")

        // Add markers for buildings
        buildings.forEach((building) => {
          try {
            const popup = new mapboxgl.Popup({ offset: 25 }).setHTML(`
              <div style="text-align: center;">
                <h3 style="font-weight: bold;">${building.name}</h3>
                <p style="font-size: 0.875rem; color: #666;">${building.description.substring(0, 100)}...</p>
                <button 
                  style="background-color: #000; color: white; padding: 4px 8px; border-radius: 4px; border: none; cursor: pointer; margin-top: 8px;"
                  onclick="window.location.href='/buildings/${building.id}'"
                >
                  Details
                </button>
              </div>
            `)

            new mapboxgl.Marker(createMarkerElement())
              .setLngLat(building.coordinates)
              .setPopup(popup)
              .addTo(map.current!)
          } catch (error) {
            console.error(`Error adding marker for ${building.name}:`, error)
          }
        })

        // Get user location if permitted
        if (navigator.geolocation) {
          navigator.geolocation.getCurrentPosition(
            (position) => {
              const userCoords: [number, number] = [position.coords.longitude, position.coords.latitude]
              setUserLocation(userCoords)

              // Add user location marker
              const userMarker = new mapboxgl.Marker({
                color: "#4285F4",
                scale: 0.8,
              })
                .setLngLat(userCoords)
                .setPopup(new mapboxgl.Popup().setHTML("<p>You are here</p>"))
                .addTo(map.current!)

              // Only center on user if they're close to campus
              const distanceFromCampus = calculateDistance(userCoords, campusCenter)
              if (distanceFromCampus < 5) {
                // Within 5km of campus
                map.current!.flyTo({
                  center: userCoords,
                  zoom: 16,
                })
              }
            },
            (error) => {
              console.log("Geolocation not available:", error.message)
            },
          )
        }
      } catch (error) {
        console.error("Error initializing map:", error)
      }
    }

    initializeMap()

    return () => {
      if (map.current) {
        map.current.remove()
        map.current = null
      }
    }
  }, [campusCenter])

  // Helper function to calculate distance between coordinates
  const calculateDistance = (coord1: [number, number], coord2: [number, number]): number => {
    const R = 6371 // Earth's radius in km
    const dLat = ((coord2[1] - coord1[1]) * Math.PI) / 180
    const dLon = ((coord2[0] - coord1[0]) * Math.PI) / 180
    const a =
      Math.sin(dLat / 2) * Math.sin(dLat / 2) +
      Math.cos((coord1[1] * Math.PI) / 180) *
        Math.cos((coord2[1] * Math.PI) / 180) *
        Math.sin(dLon / 2) *
        Math.sin(dLon / 2)
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a))
    return R * c
  }

  const handleCenterLocation = () => {
    if (userLocation && map.current) {
      map.current.flyTo({
        center: userLocation,
        zoom: 17,
      })
    } else {
      alert("Location access is not available. Please enable location permissions in your browser settings.")
    }
  }

  if (!isMounted) {
    return (
      <div className="h-[70vh] w-full flex items-center justify-center bg-muted">
        <p>Loading map...</p>
      </div>
    )
  }

  return (
    <div className="relative h-[70vh] w-full rounded-lg overflow-hidden border">
      <div ref={mapContainer} className="h-full w-full" />

      <div className="absolute bottom-4 right-4 z-[1000] flex flex-col gap-2">
        <Card>
          <CardContent className="p-2">
            <Button
              variant="outline"
              size="icon"
              onClick={handleCenterLocation}
              title="Center on your location"
              disabled={!userLocation}
            >
              <Navigation className={`h-4 w-4 ${!userLocation ? "text-muted-foreground" : ""}`} />
            </Button>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
