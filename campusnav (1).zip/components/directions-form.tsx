"use client"

import { useState, useEffect, useRef } from "react"
import { buildings } from "@/lib/data"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { calculateRoute } from "@/lib/routing"
import mapboxgl from "mapbox-gl"
import "mapbox-gl/dist/mapbox-gl.css"
import { useSearchParams } from "next/navigation"

// This would normally be in an environment variable
// For the demo, we'll use a placeholder that the user will replace
const MAPBOX_TOKEN = "pk.eyJ1IjoiamF0aW5tMDAwNyIsImEiOiJjbTl6enpvcXUxc2w1MmlzZTUzMXA5YWEzIn0.KSnQ45DAeguB7_-MHFcl5Q"

// Create a fallback marker element if the image is not available
function createMarkerElement() {
  const el = document.createElement("div")
  el.className = "marker"

  try {
    el.style.backgroundImage = `url(/marker-icon.png)`
    el.style.width = "25px"
    el.style.height = "41px"
    el.style.backgroundSize = "cover"
  } catch (error) {
    // Fallback to a simple colored div if image fails
    el.style.width = "20px"
    el.style.height = "20px"
    el.style.borderRadius = "50%"
    el.style.backgroundColor = "#3887be"
    el.style.border = "2px solid white"
  }

  el.style.cursor = "pointer"
  return el
}

export function DirectionsForm() {
  const searchParams = useSearchParams()
  const [startId, setStartId] = useState<string>(searchParams.get("from") || "")
  const [endId, setEndId] = useState<string>(searchParams.get("to") || "")
  const [route, setRoute] = useState<[number, number][]>([])
  const [directions, setDirections] = useState<string[]>([])
  const [isMounted, setIsMounted] = useState(false)
  const [isLoading, setIsLoading] = useState(false)
  const mapContainer = useRef<HTMLDivElement>(null)
  const map = useRef<mapboxgl.Map | null>(null)

  // IIT Delhi center coordinates (default view)
  const campusCenter: [number, number] = [77.1929, 28.5459]

  useEffect(() => {
    setIsMounted(true)

    if (!mapContainer.current || map.current) return

    // Initialize map
    mapboxgl.accessToken = MAPBOX_TOKEN

    try {
      map.current = new mapboxgl.Map({
        container: mapContainer.current,
        style: "mapbox://styles/mapbox/streets-v12",
        center: campusCenter,
        zoom: 15,
      })

      // Add navigation controls
      map.current.addControl(new mapboxgl.NavigationControl(), "top-right")

      // Add markers for buildings
      buildings.forEach((building) => {
        try {
          new mapboxgl.Marker(createMarkerElement())
            .setLngLat(building.coordinates)
            .setPopup(new mapboxgl.Popup({ offset: 25 }).setText(building.name))
            .addTo(map.current!)
        } catch (error) {
          console.error(`Error adding marker for ${building.name}:`, error)
        }
      })
    } catch (error) {
      console.error("Error initializing map:", error)
    }

    return () => {
      if (map.current) {
        map.current.remove()
        map.current = null
      }
    }
  }, [campusCenter])

  // If URL has from/to params, calculate route on initial load
  useEffect(() => {
    if (startId && endId && isMounted) {
      handleGetDirections()
    }
  }, [isMounted])

  const handleGetDirections = async () => {
    if (!startId || !endId || !map.current) return

    setIsLoading(true)

    const start = buildings.find((b) => b.id === startId)
    const end = buildings.find((b) => b.id === endId)

    if (!start || !end) {
      setIsLoading(false)
      return
    }

    try {
      // Clear previous route if any
      if (map.current.getSource("route")) {
        map.current.removeLayer("route")
        map.current.removeSource("route")
      }

      const { path, instructions } = await calculateRoute(start, end)
      setRoute(path)
      setDirections(instructions)

      // Add route to map
      map.current.addSource("route", {
        type: "geojson",
        data: {
          type: "Feature",
          properties: {},
          geometry: {
            type: "LineString",
            coordinates: path.map((coord) => [coord[1], coord[0]]),
          },
        },
      })

      map.current.addLayer({
        id: "route",
        type: "line",
        source: "route",
        layout: {
          "line-join": "round",
          "line-cap": "round",
        },
        paint: {
          "line-color": "#3887be",
          "line-width": 5,
          "line-opacity": 0.75,
        },
      })

      // Fit map to show the entire route
      const bounds = new mapboxgl.LngLatBounds()
      path.forEach((coord) => bounds.extend([coord[1], coord[0]]))

      map.current.fitBounds(bounds, {
        padding: 50,
        maxZoom: 15,
      })
    } catch (error) {
      console.error("Error getting directions:", error)
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
      <Card className="md:col-span-1">
        <CardHeader>
          <CardTitle>Route Planner</CardTitle>
          <CardDescription>Select your starting point and destination</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <label htmlFor="start" className="text-sm font-medium">
              Starting Point
            </label>
            <Select value={startId} onValueChange={setStartId}>
              <SelectTrigger id="start">
                <SelectValue placeholder="Select starting point" />
              </SelectTrigger>
              <SelectContent>
                {buildings.map((building) => (
                  <SelectItem key={building.id} value={building.id}>
                    {building.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <label htmlFor="end" className="text-sm font-medium">
              Destination
            </label>
            <Select value={endId} onValueChange={setEndId}>
              <SelectTrigger id="end">
                <SelectValue placeholder="Select destination" />
              </SelectTrigger>
              <SelectContent>
                {buildings.map((building) => (
                  <SelectItem key={building.id} value={building.id}>
                    {building.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </CardContent>
        <CardFooter>
          <Button
            className="w-full"
            onClick={handleGetDirections}
            disabled={!startId || !endId || startId === endId || isLoading}
          >
            {isLoading ? "Calculating..." : "Get Directions"}
          </Button>
        </CardFooter>
      </Card>

      <Card className="md:col-span-2">
        <CardHeader>
          <CardTitle>Campus Map</CardTitle>
          <CardDescription>View your route on the map</CardDescription>
        </CardHeader>
        <CardContent>{isMounted && <div className="h-[400px] w-full" ref={mapContainer}></div>}</CardContent>
      </Card>

      {directions.length > 0 && (
        <Card className="md:col-span-3">
          <CardHeader>
            <CardTitle>Directions</CardTitle>
            <CardDescription>Follow these steps to reach your destination</CardDescription>
          </CardHeader>
          <CardContent>
            <ol className="list-decimal pl-5 space-y-2">
              {directions.map((instruction, index) => (
                <li key={index}>{instruction}</li>
              ))}
            </ol>
          </CardContent>
        </Card>
      )}
    </div>
  )
}
